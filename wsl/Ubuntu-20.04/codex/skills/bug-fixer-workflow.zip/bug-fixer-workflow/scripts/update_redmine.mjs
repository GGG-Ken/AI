#!/usr/bin/env node
/**
 * update_redmine.mjs - Redmine Update Tool
 * Updates Redmine issue status to Resolved with detailed resolution notes.
 */

import { parseArgs, httpsRequest } from '../lib/utils.mjs';

const args = parseArgs(process.argv.slice(2), {
  positional: ['ISSUE_ID', 'ROOT_CAUSE', 'SOLUTION', 'TIME_SPENT'],
});

const issueId = args.ISSUE_ID;
const rootCause = (args.ROOT_CAUSE || '').replace(/\\n/g, '\n');
const solution = (args.SOLUTION || '').replace(/\\n/g, '\n');
const timeSpent = args.TIME_SPENT || '0 天 0 时';

if (!issueId || !rootCause || !solution) {
  console.error('Usage: node update_redmine.mjs <ISSUE_ID> <ROOT_CAUSE> <SOLUTION> [TIME_SPENT]');
  console.error('Example: node update_redmine.mjs 21822 "deep watch导致UI重置" "拆分为8个独立watch" "0 天 2 时"');
  process.exit(1);
}

const REDMINE_CONFIG = {
  baseUrl: 'http://redmine.ad.seevision.cn',
  username: 'linjun',
  password: 'Ziefdh6u!!',
};

async function resolveIssue(issueId, notes) {
  const url = `${REDMINE_CONFIG.baseUrl}/issues/${issueId}.json`;
  await httpsRequest(url, {
    issue: {
      status_id: 9, // 9 = 已解决
      notes: notes
    }
  }, {
    auth: REDMINE_CONFIG,
    headers: { 'Accept': 'application/json' }
  });
}

async function main() {
  try {
    console.log(`Updating Redmine Issue #${issueId} to Resolved...`);

    // Calculate next day for verification version
    const nextDay = new Date(Date.now() + 86400000);
    const nextDayStr = `${String(nextDay.getMonth() + 1).padStart(2, '0')}-${String(nextDay.getDate()).padStart(2, '0')}`;

    const notes = `**[解决用时]** ${timeSpent}

**[问题原因描述]**
${rootCause}

**[解决方案]**
${solution}

**[测试建议]**
无

**[Gerrit Change URL]**
无

**[自测结论]**
已修复

**[验证目标版本]**
${nextDayStr}及之后版本`;

    await resolveIssue(issueId, notes);
    console.log(`✓ Issue #${issueId} resolved in Redmine successfully`);

  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
}

main();
