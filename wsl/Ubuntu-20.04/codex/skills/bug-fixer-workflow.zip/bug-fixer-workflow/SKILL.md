---
name: bug-fixer-workflow
description: Professional Agentic Bug Fixing Workflow. Supports both Redmine issues and manual bug descriptions. Handles the full lifecycle: Analysis, Reproduction (Playwright), Proposal, Fix Loop (Auto-verify), and Submission.
triggers:
  - pattern: "修复问题\\s*#?(\\d+)"
    description: "Start fixing a Redmine issue (e.g., '修复问题 21660')"
  - pattern: "开始修复\\s*(.*)"
    description: "Start fixing a bug by description (e.g., '开始修复 音量滑块消失')"
  - pattern: "submit fix"
    description: "Submit the current fix"
---

# Bug Fixer Agent Skill

This skill transforms Claude into an autonomous Bug Fixing Agent. It follows a strict 4-Phase Workflow to ensure quality and accountability.

## 🟢 Phase 1: Input & Analysis

**Goal**: Understand the bug and obtain "Fail" evidence.

1.  **Context Acquisition**:
    *   Call `node .claude/skills/bug-fixer-workflow/scripts/get_task_context.mjs <INPUT>`
    *   This tool handles both Redmine IDs (fetches details/attachments) and Text Descriptions.
2.  **Code Analysis**:
    *   Read the issue details/description.
    *   Search the codebase (`grep`, `glob`) to locate relevant files and logic.
3.  **Reproduction (MANDATORY)**:
    *   You MUST attempt to reproduce the bug to confirm it exists.
    *   **Action**: Use `browser` (Playwright) tools or write a reproduction test script.
    *   **Output**: Capture a screenshot or log showing the bug. This is your "Fail" evidence.

**Deliverable to User**:
> 🔍 **Analysis Report**
> *   **Target**: [Issue ID / Description]
> *   **Locate**: [Files]
> *   **Evidence**: [Screenshot/Log of the bug]

---

## 🟡 Phase 2: Proposal

**Goal**: Plan the fix and get user approval.

1.  **Root Cause Analysis**: Explain *why* the bug is happening based on your analysis.
2.  **Solution Design**:
    *   Describe the logic changes.
    *   Show a `diff` preview if possible.
3.  **Verification Plan**: How will you prove it's fixed? (e.g., "Run the same Playwright test, expect element to remain visible").

**Deliverable to User**:
> 💡 **Fix Proposal**
> *   **Cause**: ...
> *   **Solution**: ...
> *   **Plan**: ...
>
> **Do you want to proceed? (Y/N)**

---

## 🔵 Phase 3: Execution & Loop

**Goal**: Fix the bug and obtain "Pass" evidence through **mandatory testing**.

**Upon User Confirmation (Y)**:

1.  **Initialize Environment**:
    *   Call `node .claude/skills/bug-fixer-workflow/scripts/init_fix_environment.mjs <ISSUE_ID>`
    *   This creates/switches the branch and updates Redmine status (if applicable).

2.  **Fix Loop (The "Agentic" Part)**:
    *   **Edit**: Apply your fix to the code.
    *   **Build**: Run `pnpm build` to ensure no syntax/type errors.
    *   **Self-Test (MANDATORY)**: You MUST perform self-testing before claiming completion:

        **Testing Requirements:**
        1. **Reproduce Original Bug**: Navigate to `http://localhost:13880` and verify you can reproduce the original issue
        2. **Apply Fix & Verify**: After code changes, verify the bug is fixed following the exact test steps from the issue description
        3. **Regression Testing**: Test related functionality to ensure no side effects
        4. **Evidence Collection**: Capture screenshot/log showing the fix works

        **Common Testing Scenarios:**
        - UI bugs → Use browser tools, capture before/after screenshots
        - API bugs → Use network inspector, verify correct request/response
        - Logic bugs → Add console logs with issue ID, verify behavior
        - Performance bugs → Compare metrics before/after

    *   **Check**:
        *   *If Fail*: Analyze why -> Edit Code -> Retry.
        *   *If Pass*: Proceed to Phase 4.

**⚠️ CRITICAL**: You CANNOT proceed to Phase 4 (commit) unless:
- ✅ Build passes (`pnpm build` success)
- ✅ Self-testing completed and documented
- ✅ Evidence captured (screenshot/log/description)

**Deliverable to User**:
> 🔧 **Fix Verified**
> *   **Branch**: `fix/...`
> *   **Build Status**: ✅ Passed
> *   **Self-Test**: ✅ Completed
> *   **Evidence**: [Screenshot/Log of successful fix]
> *   **Test Summary**: [Brief description of what was tested and results]

---

## 🟣 Phase 4: Commit & Record

**Goal**: Finalize the work with **separate** Git commit and Redmine update.

**Prerequisites (MUST be satisfied before Phase 4)**:
- ✅ Code changes completed
- ✅ `pnpm build` passed
- ✅ Self-testing completed with evidence
- ✅ Test results documented

1.  **Git Commit** (FIRST):
    *   Call `node .claude/skills/bug-fixer-workflow/scripts/git_commit.mjs <ISSUE_ID> [CHANGES_SUMMARY]`
    *   **Inputs**:
        *   `ISSUE_ID`: The Issue ID.
        *   `CHANGES_SUMMARY`: (Optional) Brief summary of code changes (e.g., "移除deep watch,拆分为8个独立watch").
    *   **Output**: Creates a Git commit with format: `fix(scope): #ID Subject`

2.  **Redmine Update** (SECOND):
    *   Call `node .claude/skills/bug-fixer-workflow/scripts/update_redmine.mjs <ISSUE_ID> <ROOT_CAUSE> <SOLUTION> <TIME_SPENT>`
    *   **Inputs**:
        *   `ISSUE_ID`: The Issue ID.
        *   `ROOT_CAUSE`: Detailed explanation of WHY the bug happened (for Redmine notes).
        *   `SOLUTION`: Detailed explanation of WHAT you changed (for Redmine notes).
        *   `TIME_SPENT`: Time spent (e.g., "0 天 2 时").
    *   **Output**: Updates Redmine status to "已解决" with formatted resolution notes.

**IMPORTANT**: Git commit message is SEPARATE from Redmine notes. Do NOT mix them.
- Git commit: Simple code change summary
- Redmine notes: Detailed root cause analysis + solution description + **test verification results**

**Deliverable to User**:
> ✅ **Task Completed**
> *   **Git Commit**: Created with code changes summary
> *   **Redmine**: Updated to 已解决 with detailed resolution notes (including test results)
> *   **Next Steps**: Push to remote and create PR for review

---

## Tools Reference

All tools are located in `.claude/skills/bug-fixer-workflow/scripts/`.

| Tool | Purpose | Usage |
| :--- | :--- | :--- |
| `get_task_context.mjs` | Read issue info (Redmine/Local) | `node .../get_task_context.mjs "21660"` |
| `init_fix_environment.mjs` | Setup branch & status | `node .../init_fix_environment.mjs "21660"` |
| `git_commit.mjs` | Create Git commit | `node .../git_commit.mjs "21660" "简短改动描述"` |
| `update_redmine.mjs` | Update Redmine to Resolved | `node .../update_redmine.mjs "21660" "原因" "方案" "0 天 2 时"` |

---

## Best Practices for Agent

*   **Evidence First**: Never claim a bug is fixed without a verification step (screenshot or log).
*   **Playwright Mastery**: Use Playwright to interact with the UI (`http://localhost:13880`) for both reproduction and verification.
*   **Self-Correction**: If the build fails or verification fails, **fix it yourself** before asking the user.
*   **Atomic Tools**: Use the provided `scripts/*.mjs` tools for workflow state changes; do not use raw `git` commands for branching/committing if the tools cover it.
